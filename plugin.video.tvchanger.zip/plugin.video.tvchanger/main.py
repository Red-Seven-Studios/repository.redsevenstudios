# -*- coding: utf-8 -*-
from resources.lib import kodilogging
import shutil
#from resources.lib import plugin

from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory

import routing
import logging
import xbmcaddon, os

# Keep this file to a minimum, as Kodi
# doesn't keep a compiled copy of this
ADDON = xbmcaddon.Addon()
kodilogging.config()
plugin = routing.Plugin()

AddonID = 'plugin.video.tvchanger'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")
icon = Addon.getAddonInfo('icon')

addonDir = Addon.getAddonInfo('path').decode("utf-8")

addon_data_dir = os.path.join(xbmc.translatePath("special://userdata//addon_data" ).decode("utf-8"), "pvr.iptvsimple")

local_addon_data_dir = os.path.join(xbmc.translatePath("special://userdata//addon_data" ).decode("utf-8"), AddonID)

@plugin.route('/')
def index():
    addDirectoryItem(plugin.handle, plugin.url_for(
        show_category, "adelaide"), ListItem("Adelaide"), True)
    addDirectoryItem(plugin.handle, plugin.url_for(
        show_category, "brisbane"), ListItem("Brisbane"), True)
    addDirectoryItem(plugin.handle, plugin.url_for(
        show_category, "canberra"), ListItem("Canberra"), True)
    addDirectoryItem(plugin.handle, plugin.url_for(
        show_category, "darwin"), ListItem("Darwin"), True)
    addDirectoryItem(plugin.handle, plugin.url_for(
        show_category, "hobart"), ListItem("Hobart"), True)
    addDirectoryItem(plugin.handle, plugin.url_for(
        show_category, "melbourne"), ListItem("Melbourne"), True)
    addDirectoryItem(plugin.handle, plugin.url_for(
        show_category, "perth"), ListItem("Perth"), True)
    addDirectoryItem(plugin.handle, plugin.url_for(
        show_category, "sydney"), ListItem("Sydney"), True)
    endOfDirectory(plugin.handle)


@plugin.route('/category/<category>')
def show_category(category):
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":8,"params":{"addonid":"pvr.iptvsimple","enabled":false}}')

	shutil.copy2(addonDir + '\\resources\\settings.' + category + '.xml', local_addon_data_dir)

	path = os.path.join(local_addon_data_dir, 'settings.' + category + '.xml')

	adelaidef = open(path, 'r')
	if adelaidef.mode == 'r':
		contents = adelaidef.read()

	settings = os.path.join(addon_data_dir, 'settings.xml')

	settingsf = open(settings, 'w') 
	settingsf.write(contents)
	settingsf.close()

	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":8,"params":{"addonid":"pvr.iptvsimple","enabled":true}}')


    #addDirectoryItem(
    #    plugin.handle, "", ListItem("Hello category %s!" % category_id))
    #endOfDirectory(plugin.handle)

plugin.run()